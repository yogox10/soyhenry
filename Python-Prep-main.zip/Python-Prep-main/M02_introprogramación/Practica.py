
# Este es un archivo de prueba, sin actividades =) .

# A partir del próximo módulo: M03_variablesydatos vas a tener actividades para realizar.

print('Hola Mundo!')
a = 20
while a > 0:
    print(a)
    a -= 1
